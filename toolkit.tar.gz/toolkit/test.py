import shutil
import glob
import os

path = '/media/wavereid/DATA/zt/objectDetect/darknet-master/excavator_data/*.jpg'
traintxt = '/media/wavereid/DATA/zt/objectDetect/darknet-master/data/excavator/excavator_train.txt'
testtxt = '/media/wavereid/DATA/zt/objectDetect/darknet-master/data/excavator/excavator_test.txt'
trains = open(traintxt, 'w')
for img in glob.glob(path):
    img = img.split('/')[-1]
    str = 'excavator_data/' + img +'\n'
    trains.write(str)
trains.close()